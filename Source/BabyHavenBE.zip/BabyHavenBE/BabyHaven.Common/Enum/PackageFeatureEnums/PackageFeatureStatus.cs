﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BabyHaven.Common.Enum.PackageFeatureEnums
{
    public enum PackageFeatureStatus
    {
        Active,
        Inactive,
        Pending
    }
}
